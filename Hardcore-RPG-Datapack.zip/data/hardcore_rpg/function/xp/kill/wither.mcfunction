scoreboard players set @s rpg.xp_grant 300
function hardcore_rpg:xp/grant
advancement revoke @s only hardcore_rpg:kill/wither
